package com.digit.crsApp.service;

import java.sql.PreparedStatement;
import java.util.Scanner;

import com.crsApp.CRSApp;
import com.digit.crsApp.beans.Course;

public class AdminServices {

	private PreparedStatement pstmt;

	public void menu() {
		// TODO Auto-generated method stub
		System.out.println("Select Option:");
		System.out.println("1. Add course\n"
				+ "2. Add Student\n"
				+ "3. Add Professor\n"
				+ "4. Remove Course\n"
				+ "5. Remove Professor\n"
				+ "6. Remove Student\n"
				+ "7. View All Students\n"
				+ "8. View All Courses\n"
				+ "9. View All Professors\n"
				+ "10. View All Users\n"
				+ "0. Exit\n");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		switch (n) {
		case 1: {
			addCourse();

		}
		case 0:{
			break;
		}
		default:
		}
	}

	public void addCourse() {
		try {
			Course c = new Course(1, "java", 4000, 3);
			String sql = "insert into course values(?,?,?,?)";
			pstmt = CRSApp.con.prepareStatement(sql);
			pstmt.setInt(1, c.getCid());
			pstmt.setString(2, c.getCname());
			pstmt.setInt(3, c.getFees());
			pstmt.setInt(4, c.getDur_months());
			
			int x = pstmt.executeUpdate();
			if(x>0) {
				System.out.println("Course Added is :"+c.getCname());
				menu();
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
